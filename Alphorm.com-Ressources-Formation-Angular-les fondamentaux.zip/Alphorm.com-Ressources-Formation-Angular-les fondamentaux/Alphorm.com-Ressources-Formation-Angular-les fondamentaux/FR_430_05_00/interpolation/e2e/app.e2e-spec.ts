import { InterpolationPage } from './app.po';

describe('interpolation App', () => {
  let page: InterpolationPage;

  beforeEach(() => {
    page = new InterpolationPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
