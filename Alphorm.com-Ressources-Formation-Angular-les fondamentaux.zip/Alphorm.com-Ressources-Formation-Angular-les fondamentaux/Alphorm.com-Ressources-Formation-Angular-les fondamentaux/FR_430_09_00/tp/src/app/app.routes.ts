import { Comp1Component } from './comp-1/comp-1.component';
import { Comp2Component } from './comp-2/comp-2.component';
import { Routes } from '@angular/router';

export const ROUTES:Routes = [
  {path:'comp1',component:Comp1Component},
  {path:'comp2',component:Comp2Component},
  {path:'comp1/:param',component:Comp1Component},
  {path:'',redirectTo:'comp1',pathMatch:'full'},
];