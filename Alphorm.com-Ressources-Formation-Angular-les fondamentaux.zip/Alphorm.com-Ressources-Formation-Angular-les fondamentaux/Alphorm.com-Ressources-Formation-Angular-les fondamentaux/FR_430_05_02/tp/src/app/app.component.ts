import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app works!';
  values = ['value 1','value 2','value 3','value 4'];
  show=true;

  toggle(){
    this.show = this.show?false:true;
  }

  log(value){
    console.log(value);
  }

}
