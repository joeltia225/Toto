import { Component,OnInit } from '@angular/core';
import { Http } from '@angular/http';

import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/map';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'Todos';
  todos=[];
  private todosUrl = 'api/todos';

  constructor(private http:Http){
  }

  ngOnInit(){

    this.loadData();

  }

  loadData(){
    this.http.get(this.todosUrl).map(response=>response.json().data).subscribe(todos=>{
      console.log(todos);
        this.todos = todos;
    });
  }
  
  createTodo(todo){
      this.http.post(this.todosUrl,todo).subscribe(response=>{
        this.loadData();
      });

  }

}
